# Task Description:
 get me the bodhi base url


## Overrides:
 ```json
{
  "workflow": "846bb836-ab0a-4b48-9226-1253617a3699",
  "variables": {
    "Investmentportfolio": "[\n  {\n    \"symbol\": \"TECHM\",\n    \"sector\": \"Technology\",\n    \"action\": \"accumulate\",\n    \"opportunity_score\": 82,\n    \"confidence\": 90,\n    \"conviction\": \"HIGH\",\n    \"current_price\": 1640.9,\n    \"target_price\": 1750.0,\n    \"bull_case\": \"Strong Q1 earnings beat and a major \\u20b954.05 crore block trade signal robust institutional interest. The stock is in a strong uptrend with a 9.5/10 technical score, trading near its 52-week highs with an unusual +2.2\\u03c3 positive price move.\",\n    \"bear_case\": \"Valuation looks expensive relative to its own historical standards. Any broader slowdown in IT spending or failure to sustain the Q1 margin trajectory could trigger rapid profit-taking.\",\n    \"risk_percent\": 0,\n    \"allocated_amount\": 7500,\n    \"tiers\": [\n      \"moderate\"\n    ]\n  },\n  {\n    \"symbol\": \"TCS\",\n    \"sector\": \"Technology\",\n    \"action\": \"accumulate\",\n    \"opportunity_score\": 75,\n    \"confidence\": 88,\n    \"conviction\": \"HIGH\",\n    \"current_price\": 2342.0,\n    \"target_price\": 2480.0,\n    \"bull_case\": \"A sharp +2.1\\u03c3 unusual move on 1.5x average volume indicates strong institutional accumulation at lower levels. Valuation is fair relative to history, and the business quality remains best-in-class with a perfect fundamental score.\",\n    \"bear_case\": \"Integration risks from the MHP acquisition and recent analyst target cuts could cap the upside. Broader IT sector weakness could delay the recovery.\",\n    \"risk_percent\": 15,\n    \"allocated_amount\": 7500,\n    \"tiers\": [\n      \"moderate\"\n    ]\n  }\n]",
    "Query_for_risk_assessment": "Assess this portfolio's exposure to current geopolitical conflicts, crude oil prices, US inflation and Fed policy, US-India tariffs, USD/INR moves, FII/DII flows, RBI policy, and global recession risk. Flag sector concentration and give a contrarian view where relevant.\n\nIn your final answer, include a JSON array named \"verdicts\" with one object per symbol in the portfolio: {\"symbol\": \"...\", \"verdict\": \"clear\" | \"caution\" | \"avoid\", \"notes\": \"one or two sentences\"}."
  }
}
```

## Workflow Name: AI-Equity-Analyst 



## Workflow Execution Started at 2026-08-29T12:56:37.200Z

